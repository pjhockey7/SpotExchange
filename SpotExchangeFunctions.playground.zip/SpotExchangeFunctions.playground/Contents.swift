import Foundation

var input:InputStream?
var output:OutputStream?

var readStream:Unmanaged<CFReadStream>?
var writeStream:Unmanaged<CFWriteStream>?
let host:CFString = NSString(string:"192.168.56.1")
CFStreamCreatePairWithSocketToHost(kCFAllocatorDefault,host,12345,&readStream,&writeStream)

input=readStream!.takeUnretainedValue()
output=writeStream!.takeUnretainedValue()

var wutIn:UnsafeMutablePointer<UInt8> = UnsafeMutablePointer.allocate(capacity: 8)
var wutOut:UnsafeMutablePointer<UInt8> = UnsafeMutablePointer.allocate(capacity: 8)

input!.open()
output!.open()
print("opened")

let LOG256 = 5.545177444488

func readString() -> String
{
    let length:Int = Int(readInt())
    let bytesIn:UnsafeMutablePointer<UInt8> = UnsafeMutablePointer.allocate(capacity: length)
    input!.read(bytesIn,maxLength: length)
    var word:String=""
    for i:Int in 0..<length
    {
        word+=String(Character(UnicodeScalar(bytesIn[i])))
    }
    return word
}

func writeFloat(num: Float32)
{
    let bytesOut:UnsafeMutablePointer<UInt8> = UnsafeMutablePointer.allocate(capacity: 4)
    var numVar = UInt32(num.bitPattern)
    for i in 0..<4
    {
        bytesOut[i] = UInt8(numVar%256)
        numVar>>=8
    }
    output!.write(bytesOut, maxLength: 4)
}

func readFloat() -> Float32
{
    let num = readInt()
    var numVar:UInt32
    if(num<0)
    {
        numVar = UInt32(num ^ -2147483648)+2147483648
    }
    else
    {
        numVar = UInt32(num)
    }
    return Float(bitPattern: numVar)
}

func readInt() -> Int32
{
    let bytesIn:UnsafeMutablePointer<UInt8> = UnsafeMutablePointer.allocate(capacity: 4)
    
    var sum:Int32=0
    input!.read(bytesIn, maxLength: 4)
    for i in stride(from: 3, through: 0, by: -1)
    {
        sum<<=8
        sum += Int32(bytesIn[i])
    }
    return sum
}

func writeInt(num: Int32)
{
    var numVar:UInt32
    if(num<0)
    {
        numVar = UInt32(num ^ -2147483648)+2147483648
    }
    else
    {
        numVar = UInt32(num)
    }
    let bytesOut:UnsafeMutablePointer<UInt8> = UnsafeMutablePointer.allocate(capacity: 4)
    for i in 0..<4
    {
        bytesOut[i] = UInt8(numVar%256)
        numVar>>=8
    }
    output!.write(bytesOut, maxLength: 4)
}

func writeString(word: String)
{
    let ascii = word.unicodeScalars
    writeInt(num: Int32(word.count))
    let bytesOut:UnsafeMutablePointer<UInt8> = UnsafeMutablePointer.allocate(capacity: word.count)
    for i in 0..<word.count
    {
        bytesOut[i]=UInt8(ascii[ascii.index(ascii.startIndex, offsetBy: i)].value)
    }
    output!.write(bytesOut, maxLength: word.count)
}


writeString(word:"hello world");
print(readString())
